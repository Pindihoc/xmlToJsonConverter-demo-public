const xmlConverter = require('xml-js');

//----
function isObject(value) {
    const type = typeof value;

    return value != null && (type == 'object' || type == 'function');
}

function isXMLAlike(str) {
    if (!str) {
        return false
    }

    const convertedStr = String(str)

    return convertedStr.startsWith('<') || convertedStr.startsWith('"<') || convertedStr.startsWith("'<")
}

function fiterPrefix(str) {
    let convertedStr = String(str)

    if (!convertedStr) {
        return str
    }

    let foundIndex = convertedStr.search(/:/g)

    while (foundIndex !== -1) {
        convertedStr =  convertedStr.slice(foundIndex + 1, convertedStr.length)
        foundIndex = convertedStr.search(/:/g)
    }

    return convertedStr
}

function onlyTextAttributeExisted(obj) {
    return isObject(obj) && Object.keys(obj).length === 1 && '_text' == Object.keys(obj)[0]
}

function checkNumber(val) {
    return (val && String(Number(val)) != 'NaN')
}

function reformat(obj) {
    if (isXMLAlike(obj)) {
        return format(obj)
    }

    if (!isObject(obj)) {
        return checkNumber(obj) ? Number(obj) : obj
    }

    if (onlyTextAttributeExisted(obj)) {
        let val = Object.values(obj)[0]
        return checkNumber(val) ? Number(val) : val
    }

    if (Object.keys(obj).length === 0) {
        return ''
    }

    for (const key in obj) {
        let reformatedVal = reformat(obj[key])
        let isNeedFormatAgain = 'string' === typeof reformatedVal || 'number' === typeof reformatedVal
        obj[fiterPrefix(key)] = isNeedFormatAgain ? reformat(reformatedVal) : reformatedVal
        if (fiterPrefix(key) != key) {
            delete obj[key]
        }
    }

    return obj
}

function format(val) {
    try {
        if (isObject(val)) {
            return reformat(val)
        }

        if (isXMLAlike(val)) {
            let convertedObj = xmlConverter.xml2js(val, {compact: true, spaces: 4, ignoreAttributes: true})
            return reformat(convertedObj)
        }

        return val
    } catch (e) {
        return e.message
    }
}

//---
module.exports = {format}






